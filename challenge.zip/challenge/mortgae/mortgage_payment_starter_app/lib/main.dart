import 'package:flutter/material.dart';
import 'package:mortgage_payment_starter_app/ui/mortgage_app.dart';
import 'package:mortgage_payment_starter_app/util/hexcolor.dart';

void main() {
  TextTheme textBase() {
    return TextTheme(
      title: TextStyle(
          color: Colors.black, fontFamily: "SansitaSwashed", fontSize: 19),
      body1:
          TextStyle(color: Colors.black, fontFamily: "SansitaSwashed", fontSize: 18),
    );
  }

  ThemeData defaultTheme() {
    final ThemeData base = ThemeData.light();
    return base.copyWith(
        brightness: Brightness.dark,
        primaryColor: HexColor("#ff6f00").withOpacity(1),
        textTheme: textBase(),
        appBarTheme: AppBarTheme(textTheme: textBase(), centerTitle: true),
        sliderTheme: SliderThemeData(
            thumbColor: HexColor("#e53835").withOpacity(1),
            activeTrackColor: HexColor("#e53835").withOpacity(1)),cardColor: HexColor("#f06292").withOpacity(1));
  }

  runApp(new MaterialApp(
    theme: defaultTheme(),
    home: MortgageApp(),
  ));
}
